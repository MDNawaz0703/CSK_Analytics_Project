# CSKInfo Frontend

React + Vite frontend for the CSK analytics project. Reference version — data comes from a manually maintained Excel file.

## Run

```bash
npm install
npm run dev
```

## Updating the data (manual workflow)

1. Open `data/CSK_report_2027.xlsx` and edit **Sheet1** (the other sheets are pivot tables and are ignored).
2. Install the importer dependency once: `pip install openpyxl`
3. Run `npm run sync-data` — this rewrites `src/data/stats.json`.
4. Refresh the browser (or restart `npm run dev`).

What the importer understands in Sheet1:
- the **Batsmans:** and **Bowlers:** tables (add rows freely, keep the SL.no numbers going)
- **Target Sixes** / **Target Wickets** cells
- side tables such as "Dewald Brevis (Hundred 2026--current)" (shown under "Other competitions")
- the **last updated** cell

Player names are checked against `src/data/players.json`. If you spell a name differently in Excel, add it to `ALIASES` in `scripts/import_excel.py`. An unknown name stops the import with a clear error instead of creating a duplicate player.

## Pages
- **Home** – overview
- **Team** – 2026 squad (`src/data/players.json`; ages are reference values, later computed from date of birth)
- **Achievements** – championship history
- **Analytics** – batting, bowling, all-rounders and target progress from the Excel data
- **Current Form** – impact-point ranking and other competitions

## Notes
- Impact points are a simple reference formula (`src/analytics.js`), not an official rating.
- Excel has season totals only (no match-by-match rows), so rates such as strike rate or economy are not available yet.
- Next phase: database + API + per-match data.
