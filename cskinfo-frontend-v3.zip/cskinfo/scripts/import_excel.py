#!/usr/bin/env python3
"""
Convert the manually-maintained Excel workbook into src/data/stats.json.

Usage:
    pip install openpyxl
    python scripts/import_excel.py                      # uses data/CSK_report_2027.xlsx
    python scripts/import_excel.py path/to/other.xlsx

Workflow: edit the Excel sheet ("Sheet1") -> run this script -> refresh the site.
The script finds sections by their labels (Batsmans:, Bowlers:, Target ...),
so you can add rows freely. Pivot sheets (CSKBatmans, CSK Bowlers) are ignored.
"""
import difflib
import json
import re
import sys
from datetime import datetime
from pathlib import Path

import openpyxl

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_XLSX = ROOT / "data" / "CSK_report_2027.xlsx"
PLAYERS_JSON = ROOT / "src" / "data" / "players.json"
OUT_JSON = ROOT / "src" / "data" / "stats.json"
SHEET = "Sheet1"

# Spellings used in Excel -> official name in src/data/players.json.
# Add a line here whenever you spell a name differently in the sheet.
ALIASES = {
    "matt short": "Matthew Short",
    "prashanth veer": "Prashant Veer",
    "mukesh chowdary": "Mukesh Choudhary",
}


def norm(s):
    return re.sub(r"\s+", " ", str(s or "")).strip().lower()


def num(v):
    """Excel cell -> int (blank -> 0). Raises on text so typos are caught."""
    if v is None or str(v).strip() == "":
        return 0
    if isinstance(v, (int, float)):
        return int(v)
    raise ValueError(f"expected a number, found {v!r}")


class Resolver:
    def __init__(self, official):
        self.official = {norm(n): n for n in official}
        self.warnings = []

    def __call__(self, raw, where):
        key = norm(raw)
        if key in self.official:
            return self.official[key]
        if key in ALIASES:
            return ALIASES[key]
        close = difflib.get_close_matches(key, list(self.official), n=1, cutoff=0.85)
        if close:
            name = self.official[close[0]]
            self.warnings.append(
                f"{where}: '{str(raw).strip()}' auto-matched to '{name}' "
                f"(add to ALIASES to silence this)"
            )
            return name
        raise SystemExit(
            f"ERROR {where}: unknown player '{str(raw).strip()}'. "
            f"Add them to src/data/players.json or ALIASES in this script."
        )


def read_rows(ws):
    return [[c.value for c in row] for row in ws.iter_rows()]


def find_row(rows, text):
    for i, row in enumerate(rows):
        if row and isinstance(row[0], str) and norm(row[0]).startswith(text):
            return i
    return None


def read_block(rows, start, resolve, fields, label):
    """Read player rows under a section title until the first non-numeric SL.no."""
    # header row is the first row after the title whose 2nd cell is 'Player'
    i = start + 1
    while i < len(rows) and norm(rows[i][1] if len(rows[i]) > 1 else "") != "player":
        i += 1
    i += 1
    out = []
    while i < len(rows) and isinstance(rows[i][0], (int, float)):
        r = rows[i]
        where = f"{label} row {i + 1}"
        try:
            rec = {"player": resolve(r[1], where)}
            for k, col in enumerate(fields, start=2):
                rec[fields[col] if isinstance(fields, dict) else col] = num(r[k])
        except ValueError as e:
            raise SystemExit(f"ERROR {where}: {e}")
        out.append(rec)
        i += 1
    return out


def find_target(rows, label):
    for row in rows:
        for j, cell in enumerate(row):
            if isinstance(cell, str) and norm(cell) == label:
                for v in row[j + 1:]:
                    if isinstance(v, (int, float)):
                        return int(v)
    return None


def read_side_tables(rows):
    """Tables like 'Dewald Brevis (Hundred 2026--current)' with a Matches/6s/... header."""
    tables = []
    for i, row in enumerate(rows):
        header = None
        for j in range(len(rows) - i - 1):
            nxt = rows[i + 1 + j]
            if j > 3:
                break
            if nxt and norm(nxt[0]) == "matches":
                header = i + 1 + j
                break
        title = next((c for c in row[:2] if isinstance(c, str) and c.strip()), None)
        has_numbers = any(isinstance(c, (int, float)) for c in row[:6])
        if title is None or has_numbers or header is None or header - i > 2:
            continue
        # skip the title of the main sections
        if norm(title).startswith(("batsmans", "bowlers", "csk")):
            continue
        data = rows[header + 1]
        if not isinstance(data[0], (int, float)):
            continue
        m = re.match(r"^(.*?)\s+(?:\(|F[ro]*m\s)", title.strip())
        player = m.group(1).strip() if m else title.strip()
        comp = title.strip()[len(player):].strip()
        comp = re.sub(r"^F[ro]*m\s+", "", comp)
        comp = comp.strip()
        if comp.startswith("(") and comp.endswith(")"):
            comp = comp[1:-1]
        comp = comp.replace("--", " – ").strip()
        total, innings = num(data[5]), num(data[7])
        tables.append({
            "player": player,
            "competition": comp,
            "matches": num(data[0]),
            "sixes": num(data[1]),
            "fifties": num(data[2]),
            "hundreds": num(data[3]),
            "best": num(data[4]),
            "total": total,
            "innings": innings,
            "average": round(total / innings, 2) if innings else None,
            "remark": (str(data[8]).strip() if len(data) > 8 and data[8] else ""),
            "updated": (str(rows[header][8]).replace("up res", "").strip()
                        if len(rows[header]) > 8 and rows[header][8] else ""),
        })
    return tables


def read_title_and_updated(rows):
    title = ""
    for row in rows:
        for c in row:
            if isinstance(c, str) and "PLAYERS PERFORMANCE" in c.upper():
                title = re.sub(r"\s+", " ", c).strip()
    updated = ""
    for row in rows:
        for j, c in enumerate(row):
            if isinstance(c, str) and norm(c) == "last updated":
                v = next((x for x in row[j + 1:] if x not in (None, "")), "")
                if isinstance(v, datetime):
                    updated = v.strftime("%d %b")
                else:  # fix the '5-0ct' style typo (zero instead of 'O')
                    updated = re.sub(r"(?i)0ct", "Oct", str(v)).strip()
    return title, updated


def main():
    xlsx = Path(sys.argv[1]) if len(sys.argv) > 1 else DEFAULT_XLSX
    if not xlsx.exists():
        raise SystemExit(f"Excel file not found: {xlsx}")

    official = [p["name"] for p in json.loads(PLAYERS_JSON.read_text(encoding="utf-8"))]
    resolve = Resolver(official)

    wb = openpyxl.load_workbook(xlsx, data_only=True)
    if SHEET not in wb.sheetnames:
        raise SystemExit(f"Sheet '{SHEET}' not found. Found: {wb.sheetnames}")
    rows = read_rows(wb[SHEET])

    b = find_row(rows, "batsmans")
    w = find_row(rows, "bowlers")
    if b is None or w is None:
        raise SystemExit("Could not find 'Batsmans:' and 'Bowlers:' sections in Sheet1.")

    batting = read_block(rows, b, resolve,
                         {2: "sixes", 3: "fifties", 4: "hundreds", 5: "best"}, "Batting")
    bowling = read_block(rows, w, resolve,
                         {2: "wickets", 3: "fiveW", 4: "hatTricks"}, "Bowling")

    # Merge duplicates (same player listed twice in one block)
    for name, block, keys in (("Batting", batting, ("sixes", "fifties", "hundreds")),
                              ("Bowling", bowling, ("wickets", "fiveW", "hatTricks"))):
        seen = {}
        for rec in block:
            if rec["player"] in seen:
                raise SystemExit(f"ERROR {name}: '{rec['player']}' appears twice.")
            seen[rec["player"]] = rec

    title, updated = read_title_and_updated(rows)
    out = {
        "meta": {
            "title": title,
            "lastUpdated": updated,
            "source": xlsx.name,
            "generatedAt": datetime.now().strftime("%Y-%m-%d %H:%M"),
        },
        "targets": {
            "sixes": find_target(rows, "target sixes"),
            "wickets": find_target(rows, "target wickets"),
        },
        "batting": batting,
        "bowling": bowling,
        "otherCompetitions": read_side_tables(rows),
    }
    OUT_JSON.write_text(json.dumps(out, indent=2, ensure_ascii=False), encoding="utf-8")

    print(f"OK  {OUT_JSON.relative_to(ROOT)}")
    print(f"    batters: {len(batting)} | bowlers: {len(bowling)} | "
          f"other tables: {len(out['otherCompetitions'])} | last updated: {updated or '?'}")
    for msg in resolve.warnings:
        print("    WARN", msg)


if __name__ == "__main__":
    main()
