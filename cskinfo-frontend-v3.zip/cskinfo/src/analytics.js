// Analytics calculated from the Excel-derived data (src/data/stats.json).
// Regenerate stats.json with:  npm run sync-data
import players from "./data/players.json";
import stats from "./data/stats.json";

// Reference "impact points" so players can be ranked on one scale.
// These weights are simple placeholders - tune them as the project grows.
export const BAT_WEIGHTS = { sixes: 1, fifties: 8, hundreds: 20 };
export const BOWL_WEIGHTS = { wickets: 2, fiveW: 10, hatTricks: 15 };

const sum = (arr, key) => arr.reduce((t, x) => t + (x[key] || 0), 0);

export const meta = stats.meta;
export const targets = stats.targets;
export const otherCompetitions = stats.otherCompetitions || [];

const batByName = Object.fromEntries(stats.batting.map((b) => [b.player, b]));
const bowlByName = Object.fromEntries(stats.bowling.map((b) => [b.player, b]));

export const batImpact = (b) =>
  b ? b.sixes * BAT_WEIGHTS.sixes + b.fifties * BAT_WEIGHTS.fifties + b.hundreds * BAT_WEIGHTS.hundreds : 0;
export const bowlImpact = (b) =>
  b ? b.wickets * BOWL_WEIGHTS.wickets + b.fiveW * BOWL_WEIGHTS.fiveW + b.hatTricks * BOWL_WEIGHTS.hatTricks : 0;

// One row per squad player (including those with no data yet).
export const playerRows = players.map((p) => {
  const bat = batByName[p.name] || null;
  const bowl = bowlByName[p.name] || null;
  const bi = batImpact(bat);
  const wi = bowlImpact(bowl);
  return { ...p, bat, bowl, batImpact: bi, bowlImpact: wi, impact: bi + wi, hasData: Boolean(bat || bowl) };
});

export const withData = playerRows.filter((r) => r.hasData).sort((a, b) => b.impact - a.impact);
export const withoutData = playerRows.filter((r) => !r.hasData);

export const battingBoard = [...stats.batting].sort((a, b) => b.sixes - a.sixes || b.best - a.best);
export const bowlingBoard = [...stats.bowling].sort((a, b) => b.wickets - a.wickets || b.fiveW - a.fiveW);
export const allRounders = withData.filter((r) => r.bat && r.bowl).sort((a, b) => b.impact - a.impact);

const topScorer = [...stats.batting].sort((a, b) => b.best - a.best)[0];

export const totals = {
  sixes: sum(stats.batting, "sixes"),
  fifties: sum(stats.batting, "fifties"),
  hundreds: sum(stats.batting, "hundreds"),
  wickets: sum(stats.bowling, "wickets"),
  fiveW: sum(stats.bowling, "fiveW"),
  hatTricks: sum(stats.bowling, "hatTricks"),
  highest: topScorer ? { score: topScorer.best, player: topScorer.player } : null,
};

export const progress = (value, target) => (target ? Math.min(100, (value / target) * 100) : 0);

// Form label from the ranking (relative to the squad, not an absolute rating).
export function formLabel(index, total) {
  if (index < 3) return { text: "Standout", tone: "hot" };
  if (index < Math.ceil(total * 0.6)) return { text: "Solid", tone: "solid" };
  return { text: "Building", tone: "low" };
}
