import React, { useState } from "react";
import { BarChart3, Target, Trophy, Zap } from "lucide-react";
import {
  allRounders,
  battingBoard,
  bowlingBoard,
  meta,
  progress,
  targets,
  totals
} from "../analytics";

export function BarList({ rows, valueKey, labelKey = "player", max }) {
  const top = max || Math.max(1, ...rows.map((r) => r[valueKey]));
  return (
    <div className="bar-list">
      {rows.map((r) => (
        <div className="bar-row" key={r[labelKey]}>
          <span className="bar-name">{r[labelKey]}</span>
          <div className="bar-track">
            <div className="bar-fill" style={{ width: `${(r[valueKey] / top) * 100}%` }} />
          </div>
          <strong className="bar-value">{r[valueKey]}</strong>
        </div>
      ))}
    </div>
  );
}

function DataTable({ cols, head, children }) {
  return (
    <div className="data-table" style={{ "--cols": cols }}>
      <div className="data-row data-head">{head.map((h) => <span key={h}>{h}</span>)}</div>
      {children}
    </div>
  );
}

function Batting() {
  return (
    <>
      <div className="panel">
        <h3>Most sixes</h3>
        <BarList rows={battingBoard} valueKey="sixes" />
      </div>
      <DataTable cols="1.6fr repeat(4, 1fr)" head={["Player", "6s", "50s", "100s", "Best"]}>
        {battingBoard.map((b) => (
          <div className="data-row" key={b.player}>
            <strong>{b.player}</strong>
            <span>{b.sixes}</span>
            <span>{b.fifties}</span>
            <span>{b.hundreds}</span>
            <span>{b.best}</span>
          </div>
        ))}
      </DataTable>
    </>
  );
}

function Bowling() {
  return (
    <>
      <div className="panel">
        <h3>Most wickets</h3>
        <BarList rows={bowlingBoard} valueKey="wickets" />
      </div>
      <DataTable cols="1.6fr repeat(3, 1fr)" head={["Player", "Wickets", "5W hauls", "Hat-tricks"]}>
        {bowlingBoard.map((b) => (
          <div className="data-row" key={b.player}>
            <strong>{b.player}</strong>
            <span>{b.wickets}</span>
            <span>{b.fiveW}</span>
            <span>{b.hatTricks}</span>
          </div>
        ))}
      </DataTable>
    </>
  );
}

function AllRounders() {
  return (
    <>
      <div className="panel">
        <h3>Players contributing with bat and ball</h3>
        <p className="panel-note">
          Only players who appear in both the batting and bowling sheets. Impact points combine both
          (formula shown on the Current Form page).
        </p>
        <BarList rows={allRounders.map((r) => ({ player: r.name, impact: r.impact }))} valueKey="impact" />
      </div>
      <DataTable cols="1.6fr repeat(4, 1fr)" head={["Player", "Bat impact", "Bowl impact", "6s", "Wickets"]}>
        {allRounders.map((r) => (
          <div className="data-row" key={r.name}>
            <strong>{r.name}</strong>
            <span>{r.batImpact}</span>
            <span>{r.bowlImpact}</span>
            <span>{r.bat.sixes}</span>
            <span>{r.bowl.wickets}</span>
          </div>
        ))}
      </DataTable>
    </>
  );
}

function Targets() {
  const items = [
    { label: "Team sixes", value: totals.sixes, target: targets.sixes },
    { label: "Team wickets", value: totals.wickets, target: targets.wickets }
  ];
  return (
    <div className="target-grid">
      {items.map((t) => (
        <article className="panel" key={t.label}>
          <h3>{t.label}</h3>
          <div className="target-numbers">
            <strong>{t.value}</strong>
            <span>/ {t.target}</span>
          </div>
          <div className="bar-track big">
            <div className="bar-fill" style={{ width: `${progress(t.value, t.target)}%` }} />
          </div>
          <p className="panel-note">
            {progress(t.value, t.target).toFixed(1)}% complete • {Math.max(0, t.target - t.value)} remaining
          </p>
        </article>
      ))}
    </div>
  );
}

const tabs = [
  { id: "batting", label: "Batting", Comp: Batting },
  { id: "bowling", label: "Bowling", Comp: Bowling },
  { id: "allround", label: "All-Rounders", Comp: AllRounders },
  { id: "targets", label: "Targets", Comp: Targets }
];

export default function Analytics() {
  const [active, setActive] = useState("batting");
  const Current = tabs.find((t) => t.id === active).Comp;

  return (
    <main className="content-page">
      <div className="section-heading">
        <div>
          <div className="eyebrow small"><BarChart3 size={17} /> PERFORMANCE ENGINE</div>
          <h2>Analytics</h2>
          <p>
            Post-IPL performance calculated from the squad workbook.
            {meta.lastUpdated && <> Last updated <b>{meta.lastUpdated}</b>.</>}
          </p>
        </div>
      </div>

      <div className="metric-grid">
        <article className="metric-card"><span>Total Sixes</span><strong>{totals.sixes}</strong><small>Across {battingBoard.length} batters</small></article>
        <article className="metric-card"><span>Total Wickets</span><strong>{totals.wickets}</strong><small>{totals.fiveW} five-wicket hauls • {totals.hatTricks} hat-trick</small></article>
        <article className="metric-card"><span>50s / 100s</span><strong>{totals.fifties} / {totals.hundreds}</strong><small>Milestone innings</small></article>
        <article className="metric-card"><span>Highest Score</span><strong>{totals.highest?.score ?? "—"}</strong><small>{totals.highest?.player}</small></article>
      </div>

      <div className="tab-bar" role="tablist">
        {tabs.map((t) => (
          <button
            key={t.id}
            role="tab"
            aria-selected={active === t.id}
            className={`tab-btn ${active === t.id ? "active" : ""}`}
            onClick={() => setActive(t.id)}
          >
            {t.id === "targets" ? <Target size={16} /> : t.id === "batting" ? <Zap size={16} /> : t.id === "bowling" ? <Trophy size={16} /> : <BarChart3 size={16} />}
            {t.label}
          </button>
        ))}
      </div>

      <Current />
    </main>
  );
}
