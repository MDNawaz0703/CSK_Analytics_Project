import React from "react";
import { Activity, Flame } from "lucide-react";
import {
  BAT_WEIGHTS,
  BOWL_WEIGHTS,
  formLabel,
  meta,
  otherCompetitions,
  withData,
  withoutData
} from "../analytics";

export default function CurrentForm() {
  const top = Math.max(1, ...withData.map((r) => r.impact));

  return (
    <main className="content-page">
      <div className="section-heading">
        <div>
          <div className="eyebrow small"><Activity size={17} /> RECENT PERFORMANCE</div>
          <h2>Current Form</h2>
          <p>
            Post-IPL form ranking from the squad workbook.
            {meta.lastUpdated && <> Last updated <b>{meta.lastUpdated}</b>.</>}
          </p>
        </div>
      </div>

      <div className="data-table" style={{ "--cols": "50px 1.5fr .8fr .8fr .8fr 1.4fr .9fr" }}>
        <div className="data-row data-head">
          <span>#</span><span>Player</span><span>Bat pts</span><span>Bowl pts</span><span>Impact</span><span>Form</span><span>Status</span>
        </div>
        {withData.map((r, i) => {
          const label = formLabel(i, withData.length);
          return (
            <div className="data-row" key={r.name}>
              <span className="rank">{i + 1}</span>
              <div>
                <strong>{r.name}</strong>
                <small className="sub">{r.role}</small>
              </div>
              <span>{r.batImpact || "—"}</span>
              <span>{r.bowlImpact || "—"}</span>
              <b className="impact">{r.impact}</b>
              <div className="bar-track"><div className="bar-fill" style={{ width: `${(r.impact / top) * 100}%` }} /></div>
              <span className={`pill ${label.tone}`}>{label.text}</span>
            </div>
          );
        })}
      </div>

      <p className="panel-note">
        Impact points = 6s×{BAT_WEIGHTS.sixes} + 50s×{BAT_WEIGHTS.fifties} + 100s×{BAT_WEIGHTS.hundreds} +
        wickets×{BOWL_WEIGHTS.wickets} + 5W×{BOWL_WEIGHTS.fiveW} + hat-tricks×{BOWL_WEIGHTS.hatTricks}.
        Status is relative to this squad (top 3 = Standout). This is a reference formula, not an official rating.
      </p>

      {withoutData.length > 0 && (
        <p className="panel-note">
          <b>No post-IPL data yet:</b> {withoutData.map((p) => p.name).join(", ")}.
        </p>
      )}

      {otherCompetitions.length > 0 && (
        <>
          <div className="section-heading sub-heading">
            <div className="eyebrow small"><Flame size={17} /> BEYOND THE IPL</div>
            <h2>Other competitions</h2>
          </div>
          <div className="other-grid">
            {otherCompetitions.map((o) => (
              <article className="panel" key={o.player + o.competition}>
                <div className="other-head">
                  <div>
                    <h3>{o.player}</h3>
                    <span className="sub">{o.competition}</span>
                  </div>
                  {o.remark && <span className="pill solid">{o.remark}</span>}
                </div>
                <div className="other-stats">
                  <div><strong>{o.matches}</strong><small>Matches</small></div>
                  <div><strong>{o.total}</strong><small>Runs</small></div>
                  <div><strong>{o.average ?? "—"}</strong><small>Average</small></div>
                  <div><strong>{o.best}</strong><small>Best</small></div>
                  <div><strong>{o.sixes}</strong><small>6s</small></div>
                  <div><strong>{o.fifties}/{o.hundreds}</strong><small>50s/100s</small></div>
                </div>
                {o.updated && <p className="panel-note">Updated {o.updated}</p>}
              </article>
            ))}
          </div>
        </>
      )}
    </main>
  );
}
