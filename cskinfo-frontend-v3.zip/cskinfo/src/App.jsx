import React from "react";
import { NavLink, Routes, Route, useNavigate } from "react-router-dom";
import {
  Activity,
  BarChart3,
  ChevronRight,
  Flame,
  Shield,
  Star,
  Trophy,
  Users,
  Zap
} from "lucide-react";
import squad from "./data/players.json";
import Analytics from "./pages/Analytics";
import CurrentForm from "./pages/CurrentForm";
import { meta } from "./analytics";

const navItems = [
  { label: "Home", path: "/", icon: Flame },
  { label: "Team (2026 Squad)", path: "/team", icon: Users },
  { label: "Achievements", path: "/achievements", icon: Trophy },
  { label: "Analytics", path: "/analytics", icon: BarChart3 },
  { label: "Current Form", path: "/form", icon: Activity }
];

function Logo() {
  return (
    <div className="brand">
      <div className="logo-mark">CSK</div>
      <div>
        <div className="brand-name">CSK<span>Info</span></div>
        <div className="brand-subtitle">ANALYTICS PLATFORM</div>
      </div>
      <div className="year-pill">2026</div>
    </div>
  );
}

function Header() {
  return (
    <header className="topbar">
      <Logo />
      <nav className="nav-pill">
        {navItems.map(({ label, path, icon: Icon }) => (
          <NavLink
            key={path}
            to={path}
            className={({ isActive }) => `nav-link ${isActive ? "active" : ""}`}
          >
            <Icon size={19} strokeWidth={2.2} />
            <span>{label}</span>
          </NavLink>
        ))}
      </nav>
      <div className="status-pill">
        <span className="status-dot" />
        IPL 2026 Post-Tournament{meta.lastUpdated ? ` • Data: ${meta.lastUpdated}` : ""}
      </div>
    </header>
  );
}

function StatCard({ icon: Icon, label, value, tone = "" }) {
  return (
    <div className={`stat-card ${tone}`}>
      <div className="stat-icon"><Icon size={25} /></div>
      <div>
        <div className="stat-label">{label}</div>
        <div className="stat-value">{value}</div>
      </div>
    </div>
  );
}

function Home() {
  const navigate = useNavigate();

  return (
    <main className="page-shell">
      <section className="hero-card">
        <div className="hero-glow" />
        <div className="hero-content">
          <div className="eyebrow"><Flame size={18} /> Whistle Podu Army • Official Analytics Portal</div>
          <h1>Welcome to <span>CSKInfo</span></h1>
          <p className="hero-copy">
            Your complete Chennai Super Kings player and team analytics platform.
            Deep dive into the 2026 Post-IPL squad, historical championship
            timelines, advanced metrics, and current form breakdown.
          </p>

          <div className="hero-actions">
            <button className="primary-btn" onClick={() => navigate("/team")}>
              <Users size={21} /> Explore Team Squad <ChevronRight size={22} />
            </button>
            <button className="secondary-btn" onClick={() => navigate("/achievements")}>
              <Trophy size={21} /> View Achievements
            </button>
          </div>

          <div className="hero-actions secondary-actions">
            <button className="outline-btn" onClick={() => navigate("/analytics")}>
              <BarChart3 size={21} /> Deep Analytics
            </button>
            <button className="outline-btn" onClick={() => navigate("/form")}>
              <Activity size={21} /> Current Form
            </button>
          </div>

          <div className="divider" />

          <div className="stats-grid">
            <StatCard icon={Trophy} label="IPL Trophies" value="5 Titles" />
            <StatCard icon={Star} label="Finals Appearance" value="10 Times" />
            <StatCard icon={Zap} label="Playoff Qualification" value="12 Seasons" tone="blue" />
            <StatCard icon={Shield} label="2026 Squad Captain" value="Ruturaj Gaikwad" tone="green" />
          </div>
        </div>
      </section>
    </main>
  );
}

function Team() {
  return (
    <main className="content-page">
      <div className="section-heading team-heading">
        <div>
          <div className="eyebrow small"><Users size={17} /> 2026 SQUAD</div>
          <h2>Chennai Super Kings</h2>
          <p>Current CSK squad with player role and age. Player information is separated from performance analytics so we can connect verified statistics next.</p>
        </div>
        <div className="squad-count"><strong>{squad.length}</strong><span>Players</span></div>
      </div>

      <div className="player-table">
        <div className="player-table-head">
          <span>PLAYER</span>
          <span>ROLE</span>
          <span>AGE</span>
        </div>

        {squad.map((player, index) => (
          <article className="player-row" key={player.name}>
            <div className="player-name-cell">
              <div className="player-number">{String(index + 1).padStart(2, "0")}</div>
              <div className="player-avatar">{player.name.split(" ").map(x => x[0]).join("").slice(0, 2)}</div>
              <div>
                <h3>{player.name}</h3>
                <span>{player.nationality}</span>
              </div>
            </div>
            <div className="role-cell">{player.role}</div>
            <div className="age-cell">{player.age} <small>yrs</small></div>
          </article>
        ))}
      </div>
    </main>
  );
}

function Achievements() {
  return (
    <main className="content-page">
      <div className="section-heading">
        <div>
          <div className="eyebrow small"><Trophy size={17} /> HISTORY</div>
          <h2>Achievements</h2>
          <p>CSK championship and playoff history will be populated from verified historical data.</p>
        </div>
      </div>
      <div className="achievement-grid">
        {[
          ["2010", "First IPL Title", "CSK won its maiden IPL championship."],
          ["2011", "Back-to-Back Champions", "CSK successfully defended the title."],
          ["2018", "Comeback Champions", "A memorable return after the two-year suspension."],
          ["2021", "Fourth Title", "CSK completed another dominant campaign."],
          ["2023", "Fifth Title", "CSK matched the then-record five IPL titles."]
        ].map(([year, title, text]) => (
          <article className="achievement-card" key={year}>
            <div className="achievement-year">{year}</div>
            <Trophy size={28} />
            <h3>{title}</h3>
            <p>{text}</p>
          </article>
        ))}
      </div>
    </main>
  );
}

function App() {
  return (
    <>
      <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/team" element={<Team />} />
        <Route path="/achievements" element={<Achievements />} />
        <Route path="/analytics" element={<Analytics />} />
        <Route path="/form" element={<CurrentForm />} />
      </Routes>
    </>
  );
}

export default App;
